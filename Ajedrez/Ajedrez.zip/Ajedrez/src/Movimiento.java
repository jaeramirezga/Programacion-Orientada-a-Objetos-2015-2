
public class Movimiento {
	int x , y ;
	Movimiento (int x , int y){
		this.x = x;
		this.y = y;
	}
}

class MovPeon extends Movimiento{
	public MovPeon( int mpx , int mpy  ){
		super (mpx , mpy);
	}
	
}